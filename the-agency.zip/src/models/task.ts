export interface Task {
    taskID: string;
    description: string;
    isComplete: boolean;
}
