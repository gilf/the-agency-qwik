export type txtId = 'firstName' | 'lastName' | 'codeName' | 'description';
export type taskProps = 'taskID' | 'isComplete' | 'description';